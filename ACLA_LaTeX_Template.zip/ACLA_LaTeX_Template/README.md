
# ACLA LaTeX Template for Overleaf

## 简介
此模板专为美国比较文学协会（ACLA）年会投稿设计，适配2027年休斯顿年会要求。基于标准LaTeX article类，模拟MLA格式规范。

## 快速开始
1. **上传文件**：将 `main.tex` 和 `references.bib` 上传至 Overleaf 新项目。
2. **编译设置**：确保编译器设置为 **PDFLaTeX** 或 **XeLaTeX**（推荐 XeLaTeX 以更好地支持字体）。
3. **修改内容**：
   - 替换 `main.tex` 中的标题、作者、摘要及正文内容。
   - 在 `references.bib` 中添加你的参考文献条目。
4. **匿名处理**：投稿前请注释掉 `\author` 和 `\date` 部分，或使用 `\anonymize` 命令（如果后续引入相关宏包），以满足双盲评审要求。

## 格式说明
- **字体**：Times New Roman (12pt)
- **行距**：1.5倍行距
- **页边距**：1英寸 (2.54cm)
- **引用风格**：默认使用 biblatex，建议在 preamble 中加载 `\usepackage[style=mla]{biblatex}` 并添加 `\addbibresource{references.bib}` 以符合 MLA 规范。

## 注意事项
- ACLA 官方可能每年更新具体格式要求，请务必在提交前查阅 [ACLA官网](https://www.acla.org/) 的最新 Author Guidelines。
- 本模板为通用适配版，非官方唯一指定模板，但符合历年常规排版标准。
